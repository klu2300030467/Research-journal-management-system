import { useState, useEffect } from 'react';
import { fetchJournals } from '../api/api';

const JournalList = () => {
  const [journals, setJournals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const getJournals = async () => {
      try {
        const journalsData = await fetchJournals();
        setJournals(journalsData);
      } catch (err) {
        setError("Failed to fetch journals. Please check the API server.");
        console.error("Error fetching journals:", err);
      } finally {
        setLoading(false);
      }
    };
    getJournals();
  }, []);

  if (loading) {
    return <div>Loading journals...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  if (journals.length === 0) {
    return <p>No journals available.</p>;
  }

  return (
    <div>
      <h2>Available Journals</h2>
      <ul>
        {journals.map((journal) => (
          <li key={journal.id}>
            <strong>{journal.title}</strong> - {journal.publisher}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default JournalList;