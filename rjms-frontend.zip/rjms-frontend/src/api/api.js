// src/api/api.js

export const API_BASE_URL = "http://localhost:8082/api";

// Example: fetch all journals
export const fetchJournals = async () => {
  const response = await fetch(`${API_BASE_URL}/journals`);
  if (!response.ok) {
    throw new Error("Failed to fetch journals");
  }
  return response.json();
};

// Example: add a new journal
export const createJournal = async (journal) => {
  const response = await fetch(`${API_BASE_URL}/journals`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(journal),
  });
  if (!response.ok) {
    throw new Error("Failed to create journal");
  }
  return response.json();
};
